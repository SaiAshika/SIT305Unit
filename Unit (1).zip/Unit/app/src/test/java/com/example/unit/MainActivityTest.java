package com.example.unit;

import junit.framework.TestCase;

public class MainActivityTest extends TestCase {

}